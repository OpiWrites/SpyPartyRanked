Python 3.7.4 (tags/v3.7.4:e09359112e, Jul  8 2019, 20:34:20) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
 RESTART: C:/Users/Aidan/AppData/Local/Programs/Python/Python37/SpyPartyRankedPrototype.py 
Traceback (most recent call last):
  File "C:/Users/Aidan/AppData/Local/Programs/Python/Python37/SpyPartyRankedPrototype.py", line 1, in <module>
    from ReplayParser import * ###Importing parser functions
ModuleNotFoundError: No module named 'ReplayParser'
>>> 
 RESTART: C:/Users/Aidan/AppData/Local/Programs/Python/Python37/SpyPartyRankedPrototype.py 
Traceback (most recent call last):
  File "C:/Users/Aidan/AppData/Local/Programs/Python/Python37/SpyPartyRankedPrototype.py", line 1, in <module>
    from ReplayParser.py import * ###Importing parser functions
ModuleNotFoundError: No module named 'ReplayParser'
>>> 
 RESTART: C:/Users/Aidan/AppData/Local/Programs/Python/Python37/SpyPartyRankedPrototype.py 
Traceback (most recent call last):
  File "C:/Users/Aidan/AppData/Local/Programs/Python/Python37/SpyPartyRankedPrototype.py", line 1, in <module>
    from ReplayParser.py import parse ###Import parse function
ModuleNotFoundError: No module named 'ReplayParser'
>>> 
